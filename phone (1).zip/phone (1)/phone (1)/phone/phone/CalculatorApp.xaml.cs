﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace phone
{
    /// <summary>
    /// Interaction logic for CalculatorApp.xaml
    /// </summary>
    public partial class CalculatorApp : UserControl
    {
        private double firstvalue = 0;
        private double secondvalue = 0;
        private string currentOperation = "";
        private bool operatorPressed = false;
        public CalculatorApp()
        {
            InitializeComponent();
        }

        private void NumberButton_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            string value = btn.Content.ToString();

            if (operatorPressed)
            {
                tb_result.Text = "0";
                operatorPressed = false;
            }
            if (tb_result.Text == "0")
            {
                tb_result.Text = value;

            }
            else
            {
                tb_result.Text += value;
            }
        }
        private void OperationButton_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(tb_result.Text, NumberStyles.Float,
                                 CultureInfo.InvariantCulture, out firstvalue))
                return;

            Button btn = (Button)sender;
            currentOperation = btn.Content.ToString();
            operatorPressed = true;
            
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(currentOperation) ||
                !double.TryParse(tb_result.Text, NumberStyles.Float,
                                 CultureInfo.InvariantCulture, out secondvalue))
                return;

            double result;
            switch (currentOperation)
            {
                case "+":
                    result = firstvalue + secondvalue;
                    break;
                case "−":
                    result = firstvalue - secondvalue;
                    break;
                case "×":
                    result = firstvalue * secondvalue;
                    break;
                case "÷":
                    if (secondvalue == 0)
                    {
                        return;
                    }
                    result = firstvalue / secondvalue;
                    break;
                default:
                    return;
            }
            tb_calculation.Text = $"{firstvalue}" + $"{currentOperation}" + $"{secondvalue}";
            tb_result.Text = result.ToString(CultureInfo.InvariantCulture);
            currentOperation = "";
            operatorPressed = true;
        }

        private void CommaButton_Click(object sender, EventArgs e)
        {
            if (tb_result.Text.Contains("."))
                return;
            if (operatorPressed)
            {
                tb_result.Text = "0";
                operatorPressed = false;
            }
            tb_result.Text += ".";
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            tb_result.Text = "0";
            firstvalue = 0;
            secondvalue = 0;
            currentOperation = "";
            operatorPressed = false;
            tb_calculation.Text = "";
        }
    }
}
