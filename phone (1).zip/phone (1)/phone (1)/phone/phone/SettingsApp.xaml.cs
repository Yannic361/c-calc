﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace phone
{
    /// <summary>
    /// Interaction logic for SettingsApp.xaml
    /// </summary>
    public partial class SettingsApp : UserControl
    {
        private bool toggle1On = false;
        private bool darkMode = false;

        public GradientStopCollection gsc = new GradientStopCollection();
        public GradientStopCollection gsc2 = new GradientStopCollection();
        public SettingsApp()
        {
            InitializeComponent();
            gsc.Add(new GradientStop()
            {
                Color = Color.FromRgb(225, 61, 255),
                Offset = 0.4
            });

            gsc.Add(new GradientStop()
            {
                Color = Color.FromRgb(254, 64, 160),
                Offset = 0.6
            });

            gsc2.Add(new GradientStop()
            {
                Color = Color.FromRgb(37, 247, 121),
                Offset = 0.4
            });

            gsc2.Add(new GradientStop()
            {
                Color = Color.FromRgb(37, 247, 180),
                Offset = 0.6
            });
        }
        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ThicknessAnimation anim = new ThicknessAnimation
            {
                Duration = TimeSpan.FromMilliseconds(250)
            };

            if (!toggle1On)
            {
                // Toggle nach rechts
                anim.To = new Thickness(28, 0, 0, 0);

                gradientBorder.Background = new LinearGradientBrush(gsc)
                {
                    StartPoint = new Point(0, 1),
                    EndPoint = new Point(1, 1)
                };

                gradientBorder.Effect = new DropShadowEffect
                {
                    BlurRadius = 20,
                    Color = Color.FromRgb(225, 61, 255),
                    ShadowDepth = 0,
                    Opacity = 1
                };

                // Dark Mode EIN
                Application.Current.Resources["BackgroundBrush"] =
                new SolidColorBrush(Color.FromRgb(28, 28, 30));

                Application.Current.Resources["CardBrush"] =
                new SolidColorBrush(Color.FromRgb(44, 44, 46));

                Application.Current.Resources["TextBrush"] =
                new SolidColorBrush(Colors.White);

                Application.Current.Resources["SecondaryTextBrush"] =
                new SolidColorBrush(Color.FromRgb(174, 174, 178));
            }
            else
            {
                // Toggle nach links
                anim.To = new Thickness(3, 0, 0, 0);

                gradientBorder.Background =
                new SolidColorBrush(Color.FromRgb(35, 35, 35));

                gradientBorder.Effect = null;

                // Dark Mode AUS
                Application.Current.Resources["BackgroundBrush"] =
                new SolidColorBrush(Color.FromRgb(242, 242, 247));

                Application.Current.Resources["CardBrush"] =
                new SolidColorBrush(Colors.White);

                Application.Current.Resources["TextBrush"] =
                new SolidColorBrush(Color.FromRgb(32, 32, 32));

                Application.Current.Resources["SecondaryTextBrush"] =
                new SolidColorBrush(Color.FromRgb(138, 138, 142));
            }

            btn1.BeginAnimation(MarginProperty, anim);

            toggle1On = !toggle1On;
        }


    }
}
