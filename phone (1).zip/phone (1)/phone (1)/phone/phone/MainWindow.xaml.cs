﻿using MaterialDesignThemes.Wpf;
using System.Diagnostics.Eventing.Reader;
using System.Reflection.Emit;
using System.Security.Policy;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using static MaterialDesignThemes.Wpf.Theme.ToolBar;


namespace phone
{
    
    public partial class MainWindow : Window
    {
        private DispatcherTimer timer;
        private bool settingsopen = false;
        private bool calculatoropen = false;
        public MainWindow()
        {
            InitializeComponent();
            Loaded += Window_Loaded;
            this.Left = 0;
            this.Top = SystemParameters.WorkArea.Height - this.Height;

        }

        
        private void ScreenGrid_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            double radius = mainborder.CornerRadius.TopLeft - mainborder.BorderThickness.Left;
            screenGrid.Clip = new RectangleGeometry(new Rect(e.NewSize), radius, radius);
        }

        private void Window_Loaded(object sender, EventArgs e)
        {
            Timer_Tick(this, EventArgs.Empty);

            timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            timer.Tick += Timer_Tick;
            timer.Start();
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            try
            {
                TimeZoneInfo selectedZone = null;

                if (PhoneScreen.Content is SettingsApp settings)
                {
                    if (settings.Zone.SelectedItem is TimeZoneInfo tz)
                    {
                        selectedZone = tz;
                    }
                }

                DateTime nowUtc = DateTime.UtcNow;
                DateTime displayTime;

                if (selectedZone != null)
                {
                    displayTime = TimeZoneInfo.ConvertTimeFromUtc(nowUtc, selectedZone);
                }
                else
                {
                    displayTime = DateTime.UtcNow.AddHours(1);
                }

                tb_date.Text = displayTime.ToString("HH:mm");
            }
            catch
            {
                tb_date.Text = DateTime.Now.ToString("HH:mm");
            }
        }

        //APPS/BUTTONS CLICKED


        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            if (!settingsopen)
            {
                Homescreen.Visibility = Visibility.Hidden;
                PhoneScreen.Content = new SettingsApp();
                settingsopen = true;
                standbyIcon.SetResourceReference(Control.ForegroundProperty, "TextBrush");
                bluetoothIcon.SetResourceReference(Control.ForegroundProperty, "TextBrush");
                wifiIcon.SetResourceReference(Control.ForegroundProperty, "TextBrush");
                dragmoveIcon.SetResourceReference(Control.ForegroundProperty, "TextBrush");
                tb_date.SetResourceReference(Control.ForegroundProperty, "TextBrush");
                btn_home.SetResourceReference(Control.BackgroundProperty, "TextBrush");
            }
            
            

        }
        private void HomeButton_Click(object sender, RoutedEventArgs e)
        {
            if (settingsopen)
            {
                Homescreen.Visibility = Visibility.Visible;
                PhoneScreen.Content = null;
                settingsopen = false;
                standbyIcon.ClearValue(Control.ForegroundProperty);
                standbyIcon.Foreground = Brushes.White;
                bluetoothIcon.ClearValue(Control.ForegroundProperty);
                bluetoothIcon.Foreground = Brushes.White;
                wifiIcon.ClearValue(Control.ForegroundProperty);
                wifiIcon.Foreground = Brushes.White;
                dragmoveIcon.ClearValue(Control.ForegroundProperty);
                dragmoveIcon.Foreground = Brushes.White;
                tb_date.ClearValue(Control.ForegroundProperty);
                tb_date.Foreground = Brushes.White;
                btn_home.ClearValue(Control.BackgroundProperty);
                btn_home.Foreground = Brushes.White;
            }
            else if (calculatoropen)
            {
                Homescreen.Visibility = Visibility.Visible;
                PhoneScreen.Content = null;
                calculatoropen = false;
                standbyIcon.ClearValue(Control.ForegroundProperty);
                standbyIcon.Foreground = Brushes.White;
                bluetoothIcon.ClearValue(Control.ForegroundProperty);
                bluetoothIcon.Foreground = Brushes.White;
                wifiIcon.ClearValue(Control.ForegroundProperty);
                wifiIcon.Foreground = Brushes.White;
                dragmoveIcon.ClearValue(Control.ForegroundProperty);
                dragmoveIcon.Foreground = Brushes.White;
                tb_date.ClearValue(Control.ForegroundProperty);
                tb_date.Foreground = Brushes.White;
                btn_home.ClearValue(Control.BackgroundProperty);
                btn_home.Foreground = Brushes.White;
            }

        }

        private void CalculatorButton_Click(object sender, RoutedEventArgs e)
        {
            if (!calculatoropen)
            {
                PhoneScreen.Content = new CalculatorApp();
                Homescreen.Visibility = Visibility.Hidden;
                calculatoropen = true;
                standbyIcon.SetResourceReference(Control.ForegroundProperty, "TextBrush");
                bluetoothIcon.SetResourceReference(Control.ForegroundProperty, "TextBrush");
                wifiIcon.SetResourceReference(Control.ForegroundProperty, "TextBrush");
                dragmoveIcon.SetResourceReference(Control.ForegroundProperty, "TextBrush");
                tb_date.SetResourceReference(Control.ForegroundProperty, "TextBrush");
                btn_home.SetResourceReference(Control.BackgroundProperty, "TextBrush");
            }
            else
            {
                return;
            }
            

        }

        private void StandbyButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void btn_dragmove_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }
        private void btn_dragmove_PreviewMouseRightButtonDown(object sender, RoutedEventArgs e)
        {
            this.Left = 0;
            this.Top = SystemParameters.WorkArea.Bottom - this.Height;
        }
    }

}