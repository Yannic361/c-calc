﻿using MaterialDesignThemes.Wpf;
using System.Reflection.Emit;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace phone
{
    
    public partial class MainWindow : Window
    {
        private DispatcherTimer timer;
        private bool settingsopen = false;
        private bool darkMode = false;
        public MainWindow()
        {
            InitializeComponent();
            Loaded += Window_Loaded;
            this.Left = 0;
            this.Top = SystemParameters.WorkArea.Height - this.Height;
        }

        
        

        
        private void ScreenGrid_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            double radius = mainborder.CornerRadius.TopLeft - mainborder.BorderThickness.Left;
            screenGrid.Clip = new RectangleGeometry(new Rect(e.NewSize), radius, radius);
        }

        private void Window_Loaded(object sender, EventArgs e)
        {
            timer = new DispatcherTimer()
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            timer.Tick += Timer_Tick;
            timer.Start();
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            tb_date.Text = DateTime.Now.ToString("HH:mm");
        }

        //APPS/BUTTONS CLICKED


        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            if (!settingsopen)
            {
                Homescreen.Visibility = Visibility.Hidden;
                PhoneScreen.Content = new SettingsApp();
                settingsopen = true;
            }
            
            

        }
        private void HomeButton_Click(object sender, RoutedEventArgs e)
        {
            if (settingsopen)
            {
                Homescreen.Visibility = Visibility.Visible;
                PhoneScreen.Content = null;
                settingsopen = false;
            }
        }
        private void StandbyButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void btn_dragmove_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }
        private void btn_dragmove_PreviewMouseRightButtonDown(object sender, RoutedEventArgs e)
        {
            this.Left = 0;
            this.Top = SystemParameters.WorkArea.Bottom - this.Height;
        }
    }

}